#define UTS_RELEASE "4.15.0-24-generic"
#define UTS_UBUNTU_RELEASE_ABI 24
