/* This file is auto generated, version 201807031235+glktesting7 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201807031235+glktesting7 SMP Wed Jul 4 19:21:08 UTC 2018"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "perian"
#define LINUX_COMPILER "gcc version 7.3.0 (Ubuntu 7.3.0-16ubuntu3)"
