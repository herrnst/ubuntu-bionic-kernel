/* This file is auto generated, version 25+glktesting1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#25+glktesting1 SMP Sat May 26 14:05:19 UTC 2018"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "perian"
#define LINUX_COMPILER "gcc version 7.3.0 (Ubuntu 7.3.0-16ubuntu3)"
